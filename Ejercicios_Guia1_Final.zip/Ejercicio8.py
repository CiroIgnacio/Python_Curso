#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar  5 19:12:02 2020

@author: ciro
"""

materias = ["Historia", "Matemáica", "Lengua", "Geografía"]
print(materias[-1])