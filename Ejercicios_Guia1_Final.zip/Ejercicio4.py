#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar  5 19:10:13 2020

@author: ciro
"""

nombre = input("Ingresá tu nombre: ")
print("¡Hola {}!".format(nombre))