#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar  5 19:11:38 2020

@author: ciro
"""

pagoPorHora = 400
horasPorDia = 8
diasPorSemana = 5
semanasPorMes = 4
sueldo = pagoPorHora*horasPorDia*diasPorSemana*semanasPorMes
print(sueldo)