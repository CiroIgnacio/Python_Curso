#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar  5 19:11:17 2020

@author: ciro
"""
deposito = 2000 
interes = deposito*0.05
total = deposito + interes
print(total)