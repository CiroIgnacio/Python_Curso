#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar  5 20:17:43 2020

@author: ciro
"""

numeros = [9, 2, 5, 7, 1, 12, 31, 40]
numeros.sort()
menor = numeros[0]
mayor = numeros[-1]
print(f"Lista: {numeros}\nMenor: {menor}\nMayor:{mayor}")