#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar  5 19:08:15 2020

@author: ciro
"""

nombre = input("Ingresá tu nombre: ")
edad = input("Ingresá tu edad: ")
print("Nombre: {0}\nEdad: {1}".format(nombre,edad))