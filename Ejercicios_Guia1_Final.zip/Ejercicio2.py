#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar  5 19:06:57 2020

@author: ciro
"""

saludo = "Hola Mundo!"
print(saludo)